import React from 'react';

const Explore = () =>{
    return(
        <div>
            <h1>Hii explore</h1>
        </div>
    )
}

export default Explore;