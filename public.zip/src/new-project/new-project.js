import React from 'react';

import Header from '../new-project/Header';
import Home from '../new-project/Home';
import Footer from '../new-project/Footer';
 import {Routes, Route, BrowserRouter as Router } from 'react-router-dom';
import Explore from '../new-project/Explore';
const New = () =>{
   return(
      <div>
         <Header />
         <Router>
            <Routes>
               <Route exact path="/explore" element={<Explore/>} />
               {/* <Route path="*" element ={<h2>Page not found</h2>} /> */}
            </Routes>
         </Router>   
         <Home />
      <Footer />
    </div>     
   )
}
export default New;