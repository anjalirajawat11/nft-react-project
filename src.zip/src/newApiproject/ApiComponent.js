import React from 'react'
import NewApi from './NewApi'

function ApiComponent() {
  return (
    <div>
        <NewApi />
    </div>
  )
}

export default ApiComponent